import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { PlayCircle, Clock, FileQuestion, ArrowLeft } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface Category {
  id: string;
  name: string;
}

export default function QuizListing() {
  const { categoryName } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [questionCount, setQuestionCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [isAllCategories, setIsAllCategories] = useState(false);
  const [isStarting, setIsStarting] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      
      // Check if this is "all categories" quiz
      if (categoryName === 'all-categories') {
        setIsAllCategories(true);
        // Count total questions across all categories
        const { count } = await supabase
          .from('questions')
          .select('*', { count: 'exact', head: true });
        setQuestionCount(count || 0);
        setLoading(false);
        return;
      }
      
      // Fetch categories
      const { data: catData } = await supabase
        .from('question_categories')
        .select('*')
        .order('name');
      if (catData) {
        setCategories(catData);
        const current = catData.find(c => c.name === decodeURIComponent(categoryName || ''));
        if (current) {
          setSelectedCategory(current.id);
          
          // Fetch question count
          const { count } = await supabase
            .from('questions')
            .select('*', { count: 'exact', head: true })
            .eq('category_id', current.id);
          setQuestionCount(count || 0);
        }
      }
      setLoading(false);
    };
    fetchData();
  }, [categoryName]);

  const currentCategory = categories.find(c => c.id === selectedCategory);

  const handleStartQuiz = async () => {
    if (!user) {
      toast.error("Please log in to start a quiz");
      return;
    }

    setIsStarting(true);
    
    try {
      // Create quiz session
      const { data: session, error } = await supabase
        .from("quiz_sessions")
        .insert({
          user_id: user.id,
          category_id: isAllCategories ? null : selectedCategory,
          category_ids: isAllCategories ? null : [selectedCategory],
          total_questions: 24,
          correct_count: 0,
          incorrect_count: 0,
          duration_ms: 0,
        })
        .select()
        .single();

      if (error || !session) {
        toast.error("Failed to create quiz session");
        setIsStarting(false);
        return;
      }

      navigate(`/quiz/${session.id}`);
    } catch (err) {
      toast.error("An error occurred");
      setIsStarting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-8">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Categories
          </Link>

          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {isAllCategories ? 'All Categories Quiz' : currentCategory?.name}
            </h1>
            <p className="text-lg text-muted-foreground">
              {isAllCategories 
                ? 'Test your knowledge across all football rules' 
                : 'Available quizzes for this category'}
            </p>
          </div>

          {/* Filters - only show if not all categories */}
          {!isAllCategories && (
            <div className="mb-8 flex flex-wrap gap-4">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-[280px]">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Quiz Card */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {loading ? (
              <Card className="bg-gradient-card border-border/50">
                <CardHeader>
                  <Skeleton className="h-16 w-16 rounded-lg mb-4" />
                  <Skeleton className="h-8 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full" />
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <Skeleton className="h-16 w-full" />
                    <Skeleton className="h-16 w-full" />
                  </div>
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-12 w-full" />
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-gradient-card border-border/50 shadow-card hover:shadow-glow transition-all">
                <CardHeader>
                  <div className="h-16 w-16 rounded-lg bg-gradient-hero flex items-center justify-center mb-4">
                    <PlayCircle className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-2xl">
                    {isAllCategories ? 'All Categories Quiz' : `${currentCategory?.name} Quiz`}
                  </CardTitle>
                  <CardDescription>
                    {isAllCategories 
                      ? '24 random questions from all categories combined'
                      : 'Test your knowledge with 24 carefully selected questions'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <FileQuestion className="h-5 w-5 text-primary" />
                    <div>
                      <div className="text-sm text-muted-foreground">Questions</div>
                      <div className="font-semibold">24</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-primary" />
                    <div>
                      <div className="text-sm text-muted-foreground">Duration</div>
                      <div className="font-semibold">~18 minutes</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 p-4 bg-secondary/50 rounded-lg">
                  <h4 className="font-semibold text-sm">Quiz Details:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• 45 seconds per question</li>
                    <li>• Multiple choice format</li>
                    <li>• Pass threshold: 90% (22/24 correct)</li>
                    <li>• {questionCount} questions available in database</li>
                  </ul>
                </div>

                <Button 
                  className="w-full shadow-glow" 
                  size="lg"
                  onClick={handleStartQuiz}
                  disabled={questionCount < 24 || isStarting}
                >
                  <PlayCircle className="mr-2 h-5 w-5" />
                  {isStarting ? "Starting..." : "Start Quiz"}
                </Button>

                {questionCount < 24 && (
                  <p className="text-sm text-warning text-center">
                    Not enough questions available in the database. Need at least 24 questions.
                  </p>
                )}
              </CardContent>
            </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}