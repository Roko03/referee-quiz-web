import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { LogOut, User, Trophy, Users, FileQuestion, Menu } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useUserRole } from "@/hooks/useUserRole";
import { useState } from "react";

export const Navigation = () => {
  const { user, signOut } = useAuth();
  const { isAdmin, isManager } = useUserRole();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const closeMenu = () => setMobileMenuOpen(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-hero flex items-center justify-center text-primary-foreground font-bold">
              FR
            </div>
            <span className="text-lg sm:text-xl font-bold hidden xs:inline">Football Rules Quiz</span>
            <span className="text-lg sm:text-xl font-bold xs:hidden">FR Quiz</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-4">
            <Link to="/leaderboard">
              <Button variant="ghost" size="sm">
                <Trophy className="mr-2 h-4 w-4" />
                Leaderboard
              </Button>
            </Link>

            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <User className="mr-2 h-4 w-4" />
                    Account
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {(isAdmin || isManager) && (
                    <>
                      {isAdmin && (
                        <DropdownMenuItem asChild>
                          <Link to="/admin/users" className="flex items-center w-full cursor-pointer">
                            <Users className="mr-2 h-4 w-4" />
                            Manage Users
                          </Link>
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem asChild>
                        <Link to="/admin/questions" className="flex items-center w-full cursor-pointer">
                          <FileQuestion className="mr-2 h-4 w-4" />
                          Manage Questions
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center w-full cursor-pointer">
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={signOut} className="cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link to="/auth">
                <Button variant="default" size="sm">
                  Sign In
                </Button>
              </Link>
            )}
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden">
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72">
                <SheetHeader>
                  <SheetTitle>Menu</SheetTitle>
                </SheetHeader>
                <div className="flex flex-col gap-4 mt-8">
                  <Link to="/leaderboard" onClick={closeMenu}>
                    <Button variant="ghost" className="w-full justify-start" size="lg">
                      <Trophy className="mr-2 h-5 w-5" />
                      Leaderboard
                    </Button>
                  </Link>

                  {user ? (
                    <>
                      {(isAdmin || isManager) && (
                        <>
                          {isAdmin && (
                            <Link to="/admin/users" onClick={closeMenu}>
                              <Button variant="ghost" className="w-full justify-start" size="lg">
                                <Users className="mr-2 h-5 w-5" />
                                Manage Users
                              </Button>
                            </Link>
                          )}
                          <Link to="/admin/questions" onClick={closeMenu}>
                            <Button variant="ghost" className="w-full justify-start" size="lg">
                              <FileQuestion className="mr-2 h-5 w-5" />
                              Manage Questions
                            </Button>
                          </Link>
                          <div className="border-t border-border my-2" />
                        </>
                      )}
                      <Link to="/profile" onClick={closeMenu}>
                        <Button variant="ghost" className="w-full justify-start" size="lg">
                          <User className="mr-2 h-5 w-5" />
                          Profile
                        </Button>
                      </Link>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start" 
                        size="lg"
                        onClick={() => {
                          signOut();
                          closeMenu();
                        }}
                      >
                        <LogOut className="mr-2 h-5 w-5" />
                        Sign Out
                      </Button>
                    </>
                  ) : (
                    <Link to="/auth" onClick={closeMenu}>
                      <Button variant="default" className="w-full" size="lg">
                        Sign In
                      </Button>
                    </Link>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};