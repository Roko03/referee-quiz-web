import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, PlayCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface Category {
  id: string;
  name: string;
}

export default function CustomQuiz() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [questionCount, setQuestionCount] = useState<string>("12");
  const [availableQuestions, setAvailableQuestions] = useState<number>(0);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase
        .from('question_categories')
        .select('*')
        .order('name');
      if (data) setCategories(data);
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    const fetchQuestionCount = async () => {
      if (selectedCategories.length > 0) {
        const { count } = await supabase
          .from('questions')
          .select('*', { count: 'exact', head: true })
          .in('category_id', selectedCategories);
        setAvailableQuestions(count || 0);
      } else {
        setAvailableQuestions(0);
      }
    };
    fetchQuestionCount();
  }, [selectedCategories]);

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId)
        ? prev.filter((id) => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleStartQuiz = async () => {
    const count = parseInt(questionCount);

    if (selectedCategories.length === 0) {
      toast.error("Please select at least one category");
      return;
    }

    if (count > availableQuestions) {
      toast.error(`Not enough questions available. Only ${availableQuestions} questions found.`);
      return;
    }

    // Create quiz session with multiple categories
    const { data: session, error } = await supabase
      .from("quiz_sessions")
      .insert({
        user_id: user?.id,
        category_id: selectedCategories[0], // Store first category as primary
        category_ids: selectedCategories, // Store all selected categories
        total_questions: count,
        correct_count: 0,
        incorrect_count: 0,
        duration_ms: 0,
      })
      .select()
      .single();

    if (error || !session) {
      toast.error("Failed to create quiz session");
      return;
    }

    navigate(`/quiz/${session.id}`);
  };

  const isValid = selectedCategories.length > 0 && 
    parseInt(questionCount) > 0 && 
    parseInt(questionCount) <= availableQuestions;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-2xl">
          <Link to="/" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-8">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <Card className="bg-gradient-card border-border/50 shadow-card">
            <CardHeader>
              <CardTitle className="text-2xl">Create Custom Quiz</CardTitle>
              <CardDescription>
                Select one or more categories and choose how many questions you want to answer
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert className="border-primary/50 bg-primary/5">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Custom quizzes are not included in the global leaderboard
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <div className="space-y-3">
                  <Label>Select Categories (one or more)</Label>
                  <div className="space-y-3 max-h-64 overflow-y-auto border rounded-lg p-4">
                    {categories.map((category) => (
                      <div key={category.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={category.id}
                          checked={selectedCategories.includes(category.id)}
                          onCheckedChange={() => toggleCategory(category.id)}
                        />
                        <label
                          htmlFor={category.id}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                        >
                          {category.name}
                        </label>
                      </div>
                    ))}
                  </div>
                  {selectedCategories.length > 0 && (
                    <p className="text-sm text-muted-foreground">
                      {selectedCategories.length} {selectedCategories.length === 1 ? "category" : "categories"} selected
                      {availableQuestions > 0 && ` • ${availableQuestions} questions available`}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="count">Number of Questions</Label>
                  <Input
                    id="count"
                    type="number"
                    min="1"
                    max={availableQuestions}
                    value={questionCount}
                    onChange={(e) => setQuestionCount(e.target.value)}
                    placeholder="Enter number of questions"
                    disabled={selectedCategories.length === 0}
                  />
                </div>
              </div>

              <Button 
                className="w-full shadow-glow" 
                size="lg"
                onClick={handleStartQuiz}
                disabled={!isValid}
              >
                <PlayCircle className="mr-2 h-5 w-5" />
                Start Custom Quiz
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
