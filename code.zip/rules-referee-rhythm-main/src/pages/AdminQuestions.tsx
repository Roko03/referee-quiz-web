import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { QuestionManagement } from "@/components/admin/QuestionManagement";
import { useUserRole } from "@/hooks/useUserRole";
import { Loader2 } from "lucide-react";

const AdminQuestions = () => {
  const navigate = useNavigate();
  const { isAdmin, isManager, loading } = useUserRole();

  useEffect(() => {
    if (!loading && !isAdmin && !isManager) {
      navigate("/");
    }
  }, [isAdmin, isManager, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!isAdmin && !isManager) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-16">
        <QuestionManagement />
      </div>
    </div>
  );
};

export default AdminQuestions;
