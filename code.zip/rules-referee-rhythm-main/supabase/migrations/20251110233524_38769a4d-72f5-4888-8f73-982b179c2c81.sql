-- Create app_role enum for user roles
CREATE TYPE public.app_role AS ENUM ('user', 'admin');

-- Create profiles table for user information
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name TEXT,
  last_name TEXT,
  username TEXT UNIQUE NOT NULL,
  user_agent TEXT,
  is_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'user',
  UNIQUE (user_id, role)
);

-- Create question_categories table
CREATE TABLE public.question_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create questions table
CREATE TABLE public.questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  text TEXT NOT NULL,
  category_id UUID REFERENCES public.question_categories(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create answers table
CREATE TABLE public.answers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id UUID REFERENCES public.questions(id) ON DELETE CASCADE NOT NULL,
  text TEXT NOT NULL,
  is_correct BOOLEAN NOT NULL DEFAULT false
);

-- Create quiz_sessions table
CREATE TABLE public.quiz_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id UUID REFERENCES public.question_categories(id) ON DELETE SET NULL,
  correct_count INTEGER NOT NULL DEFAULT 0,
  incorrect_count INTEGER NOT NULL DEFAULT 0,
  total_questions INTEGER NOT NULL DEFAULT 24,
  duration_ms BIGINT NOT NULL,
  passed BOOLEAN GENERATED ALWAYS AS (correct_count::float / total_questions >= 0.9) STORED,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create user_answers table
CREATE TABLE public.user_answers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_session_id UUID REFERENCES public.quiz_sessions(id) ON DELETE CASCADE NOT NULL,
  question_id UUID REFERENCES public.questions(id) ON DELETE CASCADE NOT NULL,
  selected_answer_id UUID REFERENCES public.answers(id) ON DELETE CASCADE,
  time_taken_ms INTEGER NOT NULL,
  is_correct BOOLEAN NOT NULL
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.question_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_answers ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view all profiles"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- RLS Policies for user_roles
CREATE POLICY "Anyone can view user roles"
  ON public.user_roles FOR SELECT
  USING (true);

-- RLS Policies for question_categories
CREATE POLICY "Anyone can view categories"
  ON public.question_categories FOR SELECT
  USING (true);

-- RLS Policies for questions
CREATE POLICY "Anyone can view questions"
  ON public.questions FOR SELECT
  USING (true);

-- RLS Policies for answers
CREATE POLICY "Anyone can view answers"
  ON public.answers FOR SELECT
  USING (true);

-- RLS Policies for quiz_sessions
CREATE POLICY "Users can view own quiz sessions"
  ON public.quiz_sessions FOR SELECT
  USING (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Users can insert own quiz sessions"
  ON public.quiz_sessions FOR INSERT
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- RLS Policies for user_answers
CREATE POLICY "Users can view own answers"
  ON public.user_answers FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.quiz_sessions
      WHERE quiz_sessions.id = user_answers.quiz_session_id
      AND (quiz_sessions.user_id = auth.uid() OR quiz_sessions.user_id IS NULL)
    )
  );

CREATE POLICY "Users can insert own answers"
  ON public.user_answers FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.quiz_sessions
      WHERE quiz_sessions.id = user_answers.quiz_session_id
      AND (quiz_sessions.user_id = auth.uid() OR quiz_sessions.user_id IS NULL)
    )
  );

-- Function to check if user has a role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Function to handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, first_name, last_name, username, user_agent)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'first_name',
    NEW.raw_user_meta_data->>'last_name',
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'user_agent'
  );
  
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'user');
  
  RETURN NEW;
END;
$$;

-- Trigger for new user
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_questions_updated_at
  BEFORE UPDATE ON public.questions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample categories
INSERT INTO public.question_categories (name, description) VALUES
  ('Rule 1: The Field of Play', 'Questions about the dimensions, markings, and equipment of the field'),
  ('Rule 5: The Referee', 'Questions about the referee''s powers, duties, and decisions'),
  ('Rule 8: The Start and Restart of Play', 'Questions about kick-off, dropped ball, and restarts'),
  ('Rule 11: Offside', 'Questions about offside position and offside offence'),
  ('Rule 12: Fouls and Misconduct', 'Questions about fouls, misconduct, and disciplinary sanctions');

-- Insert sample questions for Rule 12
DO $$
DECLARE
  cat_id UUID;
  q1_id UUID;
  q2_id UUID;
  q3_id UUID;
  q4_id UUID;
  q5_id UUID;
BEGIN
  SELECT id INTO cat_id FROM public.question_categories WHERE name = 'Rule 12: Fouls and Misconduct' LIMIT 1;
  
  -- Question 1
  INSERT INTO public.questions (text, category_id) VALUES 
    ('A direct free kick is awarded if a player commits which of the following offences?', cat_id)
    RETURNING id INTO q1_id;
  
  INSERT INTO public.answers (question_id, text, is_correct) VALUES
    (q1_id, 'Handball (deliberate)', true),
    (q1_id, 'Offside', false),
    (q1_id, 'Obstruction (not holding)', false),
    (q1_id, 'Dangerous play', false);
  
  -- Question 2
  INSERT INTO public.questions (text, category_id) VALUES 
    ('A player is sent off for denying an obvious goal-scoring opportunity by a handball. What happens next?', cat_id)
    RETURNING id INTO q2_id;
  
  INSERT INTO public.answers (question_id, text, is_correct) VALUES
    (q2_id, 'A penalty kick is awarded if in the penalty area', true),
    (q2_id, 'Play continues with a drop ball', false),
    (q2_id, 'An indirect free kick is awarded', false),
    (q2_id, 'The game is abandoned', false);
  
  -- Question 3
  INSERT INTO public.questions (text, category_id) VALUES 
    ('Which of the following is NOT considered serious foul play?', cat_id)
    RETURNING id INTO q3_id;
  
  INSERT INTO public.answers (question_id, text, is_correct) VALUES
    (q3_id, 'A reckless tackle', true),
    (q3_id, 'Excessive force in a challenge', false),
    (q3_id, 'Brutality', false),
    (q3_id, 'Using excessive force', false);
  
  -- Question 4
  INSERT INTO public.questions (text, category_id) VALUES 
    ('A player receives a second yellow card in the same match. What is the outcome?', cat_id)
    RETURNING id INTO q4_id;
  
  INSERT INTO public.answers (question_id, text, is_correct) VALUES
    (q4_id, 'The player is sent off (red card)', true),
    (q4_id, 'The player receives a warning', false),
    (q4_id, 'Play continues normally', false),
    (q4_id, 'A penalty kick is awarded', false);
  
  -- Question 5
  INSERT INTO public.questions (text, category_id) VALUES 
    ('Which offense results in an indirect free kick?', cat_id)
    RETURNING id INTO q5_id;
  
  INSERT INTO public.answers (question_id, text, is_correct) VALUES
    (q5_id, 'Dangerous play', true),
    (q5_id, 'Tripping an opponent', false),
    (q5_id, 'Pushing an opponent', false),
    (q5_id, 'Holding an opponent', false);
END $$;