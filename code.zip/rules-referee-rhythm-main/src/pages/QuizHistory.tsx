import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { CheckCircle2, XCircle, Clock, Calendar, ClipboardList } from "lucide-react";
import { format } from "date-fns";

interface QuizSession {
  id: string;
  correct_count: number;
  total_questions: number;
  passed: boolean;
  duration_ms: number;
  created_at: string;
  category_name: string;
}

export default function QuizHistory() {
  const { user } = useAuth();
  const [sessions, setSessions] = useState<QuizSession[]>([]);
  const [filteredSessions, setFilteredSessions] = useState<QuizSession[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  useEffect(() => {
    if (!user) return;

    const fetchHistory = async () => {
      const { data } = await supabase
        .from('quiz_sessions')
        .select(`
          *,
          question_categories(name)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (data) {
        const formattedData = data.map(s => ({
          ...s,
          category_name: (s.question_categories as any)?.name || 'Unknown Category'
        }));
        setSessions(formattedData);
        setFilteredSessions(formattedData);
      }
    };

    fetchHistory();
  }, [user]);

  useEffect(() => {
    if (filterStatus === "all") {
      setFilteredSessions(sessions);
    } else if (filterStatus === "passed") {
      setFilteredSessions(sessions.filter(s => s.passed));
    } else {
      setFilteredSessions(sessions.filter(s => !s.passed));
    }
  }, [filterStatus, sessions]);

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-24 flex items-center justify-center">
          <Card className="p-6 text-center">
            <p className="text-muted-foreground mb-4">Please sign in to view your quiz history</p>
            <Link to="/auth">
              <Button>Sign In</Button>
            </Link>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-8">My Quiz History</h1>

          {/* Filters */}
          <div className="mb-8 flex flex-wrap gap-4">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Results</SelectItem>
                <SelectItem value="passed">Passed Only</SelectItem>
                <SelectItem value="failed">Failed Only</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Quiz History */}
          {filteredSessions.length === 0 ? (
            <Card className="p-12 text-center bg-gradient-card border-border/50">
              <div className="flex flex-col items-center justify-center py-8">
                <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mb-6">
                  <ClipboardList className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">No Quiz Attempts Yet</h3>
                <p className="text-muted-foreground mb-6 max-w-md">
                  Start your journey to mastering football rules! Take your first quiz and track your progress over time.
                </p>
                <Link to="/">
                  <Button size="lg" className="shadow-glow">
                    <ClipboardList className="mr-2 h-5 w-5" />
                    Take Your First Quiz
                  </Button>
                </Link>
              </div>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredSessions.map((session) => {
                const percentage = Math.round((session.correct_count / session.total_questions) * 100);
                const durationMinutes = Math.floor(session.duration_ms / 60000);
                const durationSeconds = Math.floor((session.duration_ms % 60000) / 1000);

                return (
                  <Card key={session.id} className={`border-l-4 ${
                    session.passed ? 'border-l-success' : 'border-l-destructive'
                  } bg-gradient-card hover:shadow-glow transition-all`}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="font-semibold text-lg mb-1">{session.category_name}</h3>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Calendar className="h-4 w-4" />
                            {format(new Date(session.created_at), 'MMM d, yyyy')}
                          </div>
                        </div>
                        <div className={`p-2 rounded-full ${
                          session.passed ? 'bg-success/10' : 'bg-destructive/10'
                        }`}>
                          {session.passed ? (
                            <CheckCircle2 className="h-6 w-6 text-success" />
                          ) : (
                            <XCircle className="h-6 w-6 text-destructive" />
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 mb-4 p-4 bg-secondary/30 rounded-lg">
                        <div>
                          <div className="text-2xl font-bold">{session.correct_count}/{session.total_questions}</div>
                          <div className="text-xs text-muted-foreground">Score</div>
                        </div>
                        <div>
                          <div className={`text-2xl font-bold ${
                            session.passed ? 'text-success' : 'text-destructive'
                          }`}>
                            {percentage}%
                          </div>
                          <div className="text-xs text-muted-foreground">Percentage</div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <div className="text-lg font-bold">{durationMinutes}:{durationSeconds.toString().padStart(2, '0')}</div>
                            <div className="text-xs text-muted-foreground">Time</div>
                          </div>
                        </div>
                      </div>

                      <Link to={`/review/${session.id}`}>
                        <Button variant="outline" className="w-full">
                          View Details
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}