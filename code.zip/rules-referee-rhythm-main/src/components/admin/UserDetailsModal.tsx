import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { X, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type UserWithRole = {
  id: string;
  first_name: string | null;
  last_name: string | null;
  username: string;
  avatar_url: string | null;
  phone: string | null;
  created_at: string;
  user_roles: { role: string }[];
};

type Props = {
  user: UserWithRole | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdate: () => void;
};

export const UserDetailsModal = ({ user, open, onOpenChange, onUpdate }: Props) => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState<"admin" | "manager" | "user">("user");
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      setFirstName(user.first_name || "");
      setLastName(user.last_name || "");
      setPhone(user.phone || "");
      setRole((user.user_roles[0]?.role as "admin" | "manager" | "user") || "user");
    }
  }, [user]);

  if (!user) return null;

  const getInitials = () => {
    const first = user.first_name?.[0] || "";
    const last = user.last_name?.[0] || "";
    return (first + last).toUpperCase() || user.username.substring(0, 2).toUpperCase();
  };

  const handleUpdate = async () => {
    const { error: profileError } = await supabase
      .from("profiles")
      .update({
        first_name: firstName,
        last_name: lastName,
        phone: phone,
      })
      .eq("id", user.id);

    if (profileError) {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
      return;
    }

    const { error: roleError } = await supabase
      .from("user_roles")
      .update({ role })
      .eq("user_id", user.id);

    if (roleError) {
      toast({
        title: "Error",
        description: "Failed to update role",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Success",
      description: "User updated successfully",
    });
    onUpdate();
    onOpenChange(false);
  };

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this user?")) return;

    const { error } = await supabase.auth.admin.deleteUser(user.id);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to delete user",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      onUpdate();
      onOpenChange(false);
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl p-0 gap-0">
        <button
          onClick={() => onOpenChange(false)}
          className="absolute right-4 top-4 z-10 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="bg-gradient-hero h-32 relative">
          <Avatar className="h-24 w-24 absolute -bottom-12 left-1/2 -translate-x-1/2 border-4 border-background">
            <AvatarImage src={user.avatar_url || undefined} />
            <AvatarFallback className="text-2xl bg-primary/10 text-primary">
              {getInitials()}
            </AvatarFallback>
          </Avatar>
        </div>

        <div className="pt-16 pb-6 px-6">
          <div className="text-center mb-2">
            <div className="flex items-center justify-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <h2 className="text-2xl font-bold">
                {user.first_name} {user.last_name}
              </h2>
            </div>
            <p className="text-muted-foreground">
              {role.charAt(0).toUpperCase() + role.slice(1)} • Since {formatDate(user.created_at)}
            </p>
          </div>

          <div className="space-y-4 mt-6">
            <h3 className="font-semibold text-lg">Personal Information</h3>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>First Name</Label>
                <Input
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                />
              </div>
              <div>
                <Label>Last Name</Label>
                <Input
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Email</Label>
                <Input value={email} disabled className="opacity-50" />
              </div>
              <div>
                <Label>Phone Number</Label>
                <Input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+385 91 234 5678"
                />
              </div>
            </div>

            <div>
              <Label>Role</Label>
              <Select value={role} onValueChange={(value) => setRole(value as "admin" | "manager" | "user")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <Button onClick={handleUpdate} className="flex-1">
              Update
            </Button>
            <Button onClick={handleDelete} variant="outline" className="flex-1">
              Delete
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
