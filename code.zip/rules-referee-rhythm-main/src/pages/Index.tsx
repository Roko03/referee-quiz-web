import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { PlayCircle, Award, Trophy, Settings } from "lucide-react";
import { useNavigate } from "react-router-dom";
import heroImage from "@/assets/hero-stadium.jpg";
import { Footer } from "@/components/Footer";

interface Category {
  id: string;
  name: string;
  description: string;
  image_url: string | null;
}

export default function Index() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase
        .from('question_categories')
        .select('*')
        .order('name');
      if (data) setCategories(data);
    };
    fetchCategories();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative pt-16 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImage} 
            alt="Football stadium" 
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/80 to-background"></div>
        </div>
        
        <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-hero">
              Master the Laws of Football
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8">
              Test your knowledge of official football rules with our comprehensive quiz platform
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button size="lg" className="shadow-glow" asChild>
                <a href="#categories">
                  <PlayCircle className="mr-2 h-5 w-5" />
                  Start Quiz
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/leaderboard">
                  <Award className="mr-2 h-5 w-5" />
                  View Leaderboard
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 border-y border-border bg-gradient-card">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">24</div>
              <div className="text-muted-foreground">Questions per Quiz</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">45s</div>
              <div className="text-muted-foreground">Time per Question</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">90%</div>
              <div className="text-muted-foreground">Pass Threshold</div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section id="categories" className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Quiz Categories</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Choose a category to start testing your knowledge of football rules
            </p>
          </div>

          {/* Special Quiz Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card 
              className="bg-gradient-hero border-border/50 shadow-glow hover:shadow-glow transition-all cursor-pointer group"
              onClick={() => navigate('/quizzes/all-categories')}
            >
              <CardHeader>
                <div className="h-16 w-16 rounded-lg bg-primary-foreground/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Trophy className="h-8 w-8 text-primary-foreground" />
                </div>
                <CardTitle className="text-xl text-primary-foreground">All Categories Quiz</CardTitle>
                <CardDescription className="text-primary-foreground/80">
                  24 random questions from all categories combined
                </CardDescription>
              </CardHeader>
            </Card>

            <Card 
              className="bg-gradient-card border-primary shadow-card hover:shadow-glow transition-all cursor-pointer group"
              onClick={() => navigate('/quizzes/custom')}
            >
              <CardHeader>
                <div className="h-16 w-16 rounded-lg bg-gradient-hero flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Settings className="h-8 w-8 text-primary-foreground" />
                </div>
                <CardTitle className="text-xl">Custom Quiz</CardTitle>
                <CardDescription>
                  Choose your category and number of questions (not counted in leaderboard)
                </CardDescription>
              </CardHeader>
            </Card>
          </div>

          {/* Category Quizzes */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <Link key={category.id} to={`/quizzes/${encodeURIComponent(category.name)}`}>
                <Card className="h-full hover:shadow-glow transition-all duration-300 hover:scale-105 cursor-pointer bg-gradient-card border-border/50">
                  <CardHeader>
                    <div className="h-12 w-12 rounded-lg bg-gradient-hero flex items-center justify-center mb-4">
                      <PlayCircle className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <CardTitle className="text-xl">{category.name}</CardTitle>
                    <CardDescription className="line-clamp-2">
                      {category.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full" variant="outline">
                      View Quizzes
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}