import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, Plus, X } from "lucide-react";

type Category = {
  id: string;
  name: string;
};

type Answer = {
  id?: string;
  text: string;
  is_correct: boolean;
};

type Question = {
  id: string;
  text: string;
  category_id: string;
  answers: { id: string; text: string; is_correct: boolean }[];
};

type Props = {
  question: Question | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
};

export const AddEditQuestionModal = ({ question, open, onOpenChange, onSuccess }: Props) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [questionText, setQuestionText] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [answers, setAnswers] = useState<Answer[]>([
    { text: "", is_correct: false },
    { text: "", is_correct: false },
    { text: "", is_correct: false },
    { text: "", is_correct: false },
  ]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase
        .from("question_categories")
        .select("*")
        .order("name");
      if (data) {
        setCategories(data);
      }
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    if (question) {
      setQuestionText(question.text);
      setCategoryId(question.category_id);
      setAnswers(question.answers.map(a => ({ id: a.id, text: a.text, is_correct: a.is_correct })));
    } else {
      setQuestionText("");
      setCategoryId("");
      setAnswers([
        { text: "", is_correct: false },
        { text: "", is_correct: false },
        { text: "", is_correct: false },
        { text: "", is_correct: false },
      ]);
    }
  }, [question, open]);

  const handleAnswerChange = (index: number, field: "text" | "is_correct", value: string | boolean) => {
    const newAnswers = [...answers];
    newAnswers[index] = { ...newAnswers[index], [field]: value };
    setAnswers(newAnswers);
  };

  const addAnswer = () => {
    setAnswers([...answers, { text: "", is_correct: false }]);
  };

  const removeAnswer = (index: number) => {
    if (answers.length <= 2) {
      toast.error("You need at least 2 answers");
      return;
    }
    setAnswers(answers.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!questionText.trim()) {
      toast.error("Please enter a question");
      return;
    }

    if (!categoryId) {
      toast.error("Please select a category");
      return;
    }

    const filledAnswers = answers.filter(a => a.text.trim());
    if (filledAnswers.length < 2) {
      toast.error("Please provide at least 2 answers");
      return;
    }

    const correctAnswers = filledAnswers.filter(a => a.is_correct);
    if (correctAnswers.length === 0) {
      toast.error("Please mark at least one answer as correct");
      return;
    }

    setSaving(true);

    try {
      if (question) {
        // Update existing question
        const { error: updateError } = await supabase
          .from("questions")
          .update({ text: questionText, category_id: categoryId })
          .eq("id", question.id);

        if (updateError) throw updateError;

        // Delete old answers
        const { error: deleteError } = await supabase
          .from("answers")
          .delete()
          .eq("question_id", question.id);

        if (deleteError) throw deleteError;

        // Insert new answers
        const { error: insertError } = await supabase
          .from("answers")
          .insert(
            filledAnswers.map(a => ({
              question_id: question.id,
              text: a.text,
              is_correct: a.is_correct,
            }))
          );

        if (insertError) throw insertError;

        toast.success("Question updated successfully");
      } else {
        // Create new question
        const { data: newQuestion, error: questionError } = await supabase
          .from("questions")
          .insert({ text: questionText, category_id: categoryId })
          .select()
          .single();

        if (questionError) throw questionError;

        // Insert answers
        const { error: answersError } = await supabase
          .from("answers")
          .insert(
            filledAnswers.map(a => ({
              question_id: newQuestion.id,
              text: a.text,
              is_correct: a.is_correct,
            }))
          );

        if (answersError) throw answersError;

        toast.success("Question created successfully");
      }

      onSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error("Error saving question:", error);
      toast.error("Failed to save question");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{question ? "Edit Question" : "Add New Question"}</DialogTitle>
          <DialogDescription>
            {question ? "Update the question details below" : "Create a new question with multiple answers"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger id="category">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="question">Question</Label>
            <Textarea
              id="question"
              value={questionText}
              onChange={(e) => setQuestionText(e.target.value)}
              placeholder="Enter your question..."
              rows={3}
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Answers (at least 2 required)</Label>
              <Button type="button" onClick={addAnswer} size="sm" variant="outline">
                <Plus className="h-4 w-4 mr-1" />
                Add Answer
              </Button>
            </div>

            {answers.map((answer, index) => (
              <div key={index} className="flex items-start gap-2 p-3 border rounded-lg">
                <div className="flex items-center pt-2">
                  <Checkbox
                    checked={answer.is_correct}
                    onCheckedChange={(checked) => 
                      handleAnswerChange(index, "is_correct", checked === true)
                    }
                  />
                </div>
                <div className="flex-1">
                  <Input
                    value={answer.text}
                    onChange={(e) => handleAnswerChange(index, "text", e.target.value)}
                    placeholder={`Answer ${index + 1}...`}
                  />
                </div>
                {answers.length > 2 && (
                  <Button
                    type="button"
                    onClick={() => removeAnswer(index)}
                    size="icon"
                    variant="ghost"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            <p className="text-sm text-muted-foreground">
              Check the box next to the correct answer(s)
            </p>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {question ? "Update Question" : "Create Question"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
