import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";

export default function Terms() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <main className="flex-1 pt-16">
        <div className="container mx-auto px-4 py-12 max-w-4xl">
          <h1 className="text-4xl font-bold mb-8">Terms of Service</h1>
          
          <div className="space-y-6 text-muted-foreground">
            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Agreement to Terms</h2>
              <p>
                By accessing and using Football Rules Quiz, you agree to be bound by these Terms 
                of Service and all applicable laws and regulations. If you do not agree with any 
                of these terms, you are prohibited from using this platform.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Use License</h2>
              <p className="mb-3">
                Permission is granted to temporarily access and use Football Rules Quiz for 
                personal, non-commercial purposes. This license does not include:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Modifying or copying the materials</li>
                <li>Using the materials for commercial purposes</li>
                <li>Attempting to reverse engineer any software</li>
                <li>Removing any copyright or proprietary notations</li>
                <li>Transferring the materials to another person</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">User Accounts</h2>
              <p className="mb-3">When you create an account, you agree to:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Provide accurate and complete information</li>
                <li>Maintain the security of your password</li>
                <li>Accept responsibility for all activities under your account</li>
                <li>Notify us immediately of any unauthorized use</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Prohibited Activities</h2>
              <p className="mb-3">You may not:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Use the platform for any illegal purpose</li>
                <li>Attempt to gain unauthorized access to any part of the platform</li>
                <li>Interfere with or disrupt the platform's operation</li>
                <li>Upload malicious code or harmful content</li>
                <li>Harass, abuse, or harm other users</li>
                <li>Impersonate any person or entity</li>
                <li>Collect information about other users without consent</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Quiz Content</h2>
              <p>
                All quiz questions, answers, and related content are provided for educational 
                purposes. While we strive for accuracy, we do not guarantee that all content 
                is error-free or up-to-date with the latest official football rules.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">User Generated Content</h2>
              <p className="mb-3">
                By submitting content to our platform, you grant us:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>A non-exclusive, worldwide, royalty-free license to use your content</li>
                <li>The right to display your username and scores on leaderboards</li>
                <li>The right to moderate or remove content that violates our policies</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Intellectual Property</h2>
              <p>
                The platform and its original content, features, and functionality are owned 
                by Football Rules Quiz and are protected by international copyright, trademark, 
                and other intellectual property laws.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Disclaimer</h2>
              <p>
                The platform is provided "as is" without warranties of any kind. We do not 
                guarantee that the platform will be uninterrupted, secure, or error-free. 
                Your use of the platform is at your own risk.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Limitation of Liability</h2>
              <p>
                Football Rules Quiz shall not be liable for any indirect, incidental, special, 
                consequential, or punitive damages resulting from your use or inability to use 
                the platform.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Termination</h2>
              <p>
                We reserve the right to terminate or suspend your account immediately, without 
                prior notice, for conduct that we believe violates these Terms of Service or 
                is harmful to other users, us, or third parties.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Changes to Terms</h2>
              <p>
                We reserve the right to modify these terms at any time. We will notify users 
                of any material changes. Your continued use of the platform after changes 
                constitutes acceptance of the new terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Governing Law</h2>
              <p>
                These Terms shall be governed by and construed in accordance with applicable 
                laws, without regard to conflict of law provisions.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-3">Contact Information</h2>
              <p>
                If you have any questions about these Terms of Service, please contact us 
                through our platform or via the contact information provided on our website.
              </p>
            </section>

            <div className="pt-8 border-t border-border">
              <p className="text-sm">
                Last Updated: {new Date().toLocaleDateString()}
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
