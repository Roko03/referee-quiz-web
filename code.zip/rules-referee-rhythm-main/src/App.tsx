import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import QuizListing from "./pages/QuizListing";
import CustomQuiz from "./pages/CustomQuiz";
import ActiveQuiz from "./pages/ActiveQuiz";
import QuizReview from "./pages/QuizReview";
import QuizHistory from "./pages/QuizHistory";
import ProfileEdit from "./pages/ProfileEdit";
import Leaderboard from "./pages/Leaderboard";
import AdminUsers from "./pages/AdminUsers";
import AdminQuestions from "./pages/AdminQuestions";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/quizzes/:categoryName" element={<QuizListing />} />
            <Route path="/quizzes/custom" element={<CustomQuiz />} />
            <Route path="/quiz/:id" element={<ActiveQuiz />} />
            <Route path="/review/:id" element={<QuizReview />} />
            <Route path="/profile" element={<ProfileEdit />} />
            <Route path="/profile/history" element={<QuizHistory />} />
            <Route path="/profile/edit" element={<ProfileEdit />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route path="/admin/questions" element={<AdminQuestions />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;