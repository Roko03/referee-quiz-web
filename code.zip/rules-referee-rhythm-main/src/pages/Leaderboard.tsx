import { useEffect, useState } from "react";
import { Navigation } from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { Trophy, Medal, Award } from "lucide-react";
import { Footer } from "@/components/Footer";

interface LeaderboardEntry {
  username: string;
  totalQuizzes: number;
  averageScore: number;
  passRate: number;
}

export default function Leaderboard() {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      const { data: sessions } = await supabase
        .from('quiz_sessions')
        .select(`
          user_id,
          correct_count,
          total_questions,
          passed
        `)
        .eq('total_questions', 24)
        .not('user_id', 'is', null);

      if (sessions) {
        const userStats = new Map<string, {
          totalQuizzes: number;
          totalScore: number;
          passedQuizzes: number;
        }>();

        sessions.forEach(session => {
          if (!session.user_id) return;
          
          const stats = userStats.get(session.user_id) || {
            totalQuizzes: 0,
            totalScore: 0,
            passedQuizzes: 0
          };

          stats.totalQuizzes++;
          stats.totalScore += (session.correct_count / session.total_questions) * 100;
          if (session.passed) stats.passedQuizzes++;

          userStats.set(session.user_id, stats);
        });

        const leaderboardData = await Promise.all(
          Array.from(userStats.entries()).map(async ([userId, stats]) => {
            const { data: profile } = await supabase
              .from('profiles')
              .select('username')
              .eq('id', userId)
              .single();

            return {
              username: profile?.username || 'Anonymous',
              totalQuizzes: stats.totalQuizzes,
              averageScore: Math.round(stats.totalScore / stats.totalQuizzes),
              passRate: Math.round((stats.passedQuizzes / stats.totalQuizzes) * 100)
            };
          })
        );

        leaderboardData.sort((a, b) => b.averageScore - a.averageScore);
        setLeaderboard(leaderboardData.slice(0, 20));
      }
    };

    fetchLeaderboard();
  }, []);

  const getMedalIcon = (index: number) => {
    if (index === 0) return <Trophy className="h-6 w-6 text-warning" />;
    if (index === 1) return <Medal className="h-6 w-6 text-muted-foreground" />;
    if (index === 2) return <Award className="h-6 w-6 text-warning/70" />;
    return <span className="text-lg font-semibold text-muted-foreground">{index + 1}</span>;
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />
      
      <div className="pt-24 pb-16 flex-1">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <div className="text-center mb-12">
            <div className="h-16 w-16 rounded-full bg-gradient-hero flex items-center justify-center mx-auto mb-4">
              <Trophy className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Global Leaderboard</h1>
            <p className="text-lg text-muted-foreground">
              Top performers ranked by average quiz scores
            </p>
          </div>

          <Card className="shadow-card bg-gradient-card">
            <CardHeader>
              <CardTitle>Top 20 Players</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leaderboard.map((entry, index) => (
                  <div
                    key={entry.username}
                    className={`flex items-center gap-4 p-4 rounded-lg ${
                      index < 3 ? 'bg-primary/10 border border-primary/20' : 'bg-secondary/30'
                    }`}
                  >
                    <div className="w-12 flex items-center justify-center">
                      {getMedalIcon(index)}
                    </div>

                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-gradient-hero text-primary-foreground">
                        {entry.username.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <div className="font-semibold">{entry.username}</div>
                      <div className="text-sm text-muted-foreground">
                        {entry.totalQuizzes} {entry.totalQuizzes === 1 ? 'quiz' : 'quizzes'}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">{entry.averageScore}%</div>
                      <div className="text-sm text-muted-foreground">
                        {entry.passRate}% pass rate
                      </div>
                    </div>
                  </div>
                ))}

                {leaderboard.length === 0 && (
                  <div className="text-center py-12 text-muted-foreground">
                    No quiz attempts yet. Be the first to take a quiz!
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}