import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, XCircle, ArrowLeft, Home } from "lucide-react";

interface ReviewQuestion {
  question_text: string;
  selected_answer_text: string;
  correct_answer_text: string;
  is_correct: boolean;
}

interface QuizSession {
  correct_count: number;
  total_questions: number;
  passed: boolean;
  duration_ms: number;
}

export default function QuizReview() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [session, setSession] = useState<QuizSession | null>(null);
  const [reviewData, setReviewData] = useState<ReviewQuestion[]>([]);

  useEffect(() => {
    const fetchReview = async () => {
      const { data: sessionData } = await supabase
        .from('quiz_sessions')
        .select('*')
        .eq('id', id)
        .single();

      if (sessionData) {
        setSession(sessionData);

        const { data: answersData } = await supabase
          .from('user_answers')
          .select(`
            *,
            question_id,
            selected_answer_id
          `)
          .eq('quiz_session_id', id);

        if (answersData) {
          const reviewQuestions = await Promise.all(
            answersData.map(async (ua) => {
              const { data: question } = await supabase
                .from('questions')
                .select('text')
                .eq('id', ua.question_id)
                .single();

              const { data: selectedAnswer } = await supabase
                .from('answers')
                .select('text')
                .eq('id', ua.selected_answer_id)
                .single();

              const { data: correctAnswer } = await supabase
                .from('answers')
                .select('text')
                .eq('question_id', ua.question_id)
                .eq('is_correct', true)
                .single();

              return {
                question_text: question?.text || '',
                selected_answer_text: selectedAnswer?.text || '',
                correct_answer_text: correctAnswer?.text || '',
                is_correct: ua.is_correct
              };
            })
          );

          setReviewData(reviewQuestions);
        }
      }
    };

    fetchReview();
  }, [id]);

  if (!session) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-24 flex items-center justify-center">
          <p className="text-muted-foreground">Loading results...</p>
        </div>
      </div>
    );
  }

  const percentage = Math.round((session.correct_count / session.total_questions) * 100);
  const durationMinutes = Math.floor(session.duration_ms / 60000);
  const durationSeconds = Math.floor((session.duration_ms % 60000) / 1000);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          {/* Results Summary */}
          <Card className={`mb-8 ${session.passed ? 'border-success' : 'border-destructive'} border-2 shadow-card`}>
            <CardHeader className="text-center">
              <div className={`mx-auto h-20 w-20 rounded-full flex items-center justify-center mb-4 ${
                session.passed ? 'bg-success/10' : 'bg-destructive/10'
              }`}>
                {session.passed ? (
                  <CheckCircle2 className="h-12 w-12 text-success" />
                ) : (
                  <XCircle className="h-12 w-12 text-destructive" />
                )}
              </div>
              <CardTitle className="text-3xl">
                {session.passed ? 'Congratulations! 🎉' : 'Keep Practicing! 💪'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-4xl font-bold mb-2">{session.correct_count}/{session.total_questions}</div>
                  <div className="text-sm text-muted-foreground">Correct Answers</div>
                </div>
                <div>
                  <div className={`text-4xl font-bold mb-2 ${session.passed ? 'text-success' : 'text-destructive'}`}>
                    {percentage}%
                  </div>
                  <div className="text-sm text-muted-foreground">Score</div>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">{durationMinutes}:{durationSeconds.toString().padStart(2, '0')}</div>
                  <div className="text-sm text-muted-foreground">Time Taken</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Question Review */}
          <div className="space-y-4 mb-8">
            <h2 className="text-2xl font-bold mb-4">Detailed Review</h2>
            {reviewData.map((item, index) => (
              <Card key={index} className={`border-l-4 ${
                item.is_correct ? 'border-l-success' : 'border-l-destructive'
              } bg-gradient-card`}>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3 mb-3">
                    {item.is_correct ? (
                      <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0 mt-1" />
                    ) : (
                      <XCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-1" />
                    )}
                    <div className="flex-1">
                      <h3 className="font-semibold mb-2">Question {index + 1}</h3>
                      <p className="text-foreground mb-4">{item.question_text}</p>
                      
                      <div className="space-y-2">
                        {!item.is_correct && (
                          <div className="p-3 bg-destructive/10 rounded-lg">
                            <span className="text-sm font-semibold text-destructive">Your answer: </span>
                            <span className="text-sm">{item.selected_answer_text}</span>
                          </div>
                        )}
                        <div className="p-3 bg-success/10 rounded-lg">
                          <span className="text-sm font-semibold text-success">Correct answer: </span>
                          <span className="text-sm">{item.correct_answer_text}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              variant="outline" 
              size="lg"
              className="flex-1"
              onClick={() => navigate('/')}
            >
              <Home className="mr-2 h-5 w-5" />
              Back to Home
            </Button>
            <Button 
              size="lg"
              className="flex-1 shadow-glow"
              onClick={() => navigate(-2)}
            >
              <ArrowLeft className="mr-2 h-5 w-5" />
              Try Another Quiz
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}