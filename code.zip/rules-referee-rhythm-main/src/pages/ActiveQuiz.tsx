import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface Question {
  id: string;
  text: string;
}

interface Answer {
  id: string;
  text: string;
  is_correct: boolean;
}

export default function ActiveQuiz() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [searchParams] = useState(new URLSearchParams(window.location.search));
  
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [timeLeft, setTimeLeft] = useState(45);
  const [startTime, setStartTime] = useState(Date.now());
  const [loadingAnswers, setLoadingAnswers] = useState(false);
  const [quizStartTime] = useState(Date.now());
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [userAnswers, setUserAnswers] = useState<Array<{
    questionId: string;
    answerId: string;
    timeTaken: number;
    isCorrect: boolean;
  }>>([]);

  useEffect(() => {
    const loadQuiz = async () => {
      if (!id) return;

      const { data: session, error: sessionError } = await supabase
        .from("quiz_sessions")
        .select("*, question_categories(*)")
        .eq("id", id)
        .single();

      if (sessionError || !session) {
        console.error("Failed to load quiz session");
        navigate("/");
        return;
      }

      // Fetch questions based on total_questions count and category selection
      let questionQuery = supabase
        .from("questions")
        .select("*, answers(*)")
        .order("created_at", { ascending: false })
        .limit(session.total_questions);

      // If quiz has multiple categories (custom quiz), filter by them
      if (session.category_ids && session.category_ids.length > 0) {
        questionQuery = questionQuery.in("category_id", session.category_ids);
        setCategoryId(session.category_ids[0]);
      } else if (session.category_id) {
        // If quiz has a single category, filter by it
        questionQuery = questionQuery.eq("category_id", session.category_id);
        setCategoryId(session.category_id);
      } else {
        // If neither, it's an "all categories" quiz - no filter needed
        setCategoryId(null);
      }

      const { data: questionsData, error: questionsError } = await questionQuery;

      if (questionsError || !questionsData || questionsData.length === 0) {
        console.error("Failed to load questions");
        navigate("/");
        return;
      }

      // Shuffle questions for variety
      const shuffled = questionsData.sort(() => Math.random() - 0.5);
      
      // Extract questions and store them
      const questionList = shuffled.map(q => ({ id: q.id, text: q.text }));
      setQuestions(questionList);

      // Load first question's answers
      if (shuffled[0]?.answers) {
        setAnswers(shuffled[0].answers.sort(() => Math.random() - 0.5));
      }
    };

    loadQuiz();
  }, [id, navigate]);

  useEffect(() => {
    if (questions.length > 0 && currentQuestionIndex < questions.length) {
      const fetchAnswers = async () => {
        setLoadingAnswers(true);
        const { data: answersData } = await supabase
          .from('answers')
          .select('*')
          .eq('question_id', questions[currentQuestionIndex].id);
        
        if (answersData) {
          setAnswers(answersData.sort(() => Math.random() - 0.5));
        }
        setLoadingAnswers(false);
      };
      fetchAnswers();
      setSelectedAnswer("");
      setTimeLeft(45);
      setStartTime(Date.now());
    }
  }, [currentQuestionIndex, questions]);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      handleNext();
    }
  }, [timeLeft]);

  const handleAnswerSelect = (answerId: string) => {
    setSelectedAnswer(answerId);
  };

  const handleNext = async () => {
    const timeTaken = Date.now() - startTime;
    const correctAnswer = answers.find(a => a.is_correct);
    const isCorrect = selectedAnswer === correctAnswer?.id;

    const newUserAnswers = [...userAnswers, {
      questionId: questions[currentQuestionIndex].id,
      answerId: selectedAnswer || answers[0].id,
      timeTaken,
      isCorrect
    }];
    setUserAnswers(newUserAnswers);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Quiz finished - save results
      const correctCount = newUserAnswers.filter(a => a.isCorrect).length;
      const incorrectCount = newUserAnswers.filter(a => !a.isCorrect).length;
      const totalDuration = Date.now() - quizStartTime;

      const { data: sessionData, error } = await supabase
        .from('quiz_sessions')
        .insert({
          user_id: user?.id || null,
          category_id: categoryId,
          correct_count: correctCount,
          incorrect_count: incorrectCount,
          duration_ms: totalDuration,
          total_questions: questions.length,
        })
        .select()
        .single();

      if (sessionData && !error) {
        // Save individual answers
        await supabase.from('user_answers').insert(
          newUserAnswers.map(ua => ({
            quiz_session_id: sessionData.id,
            question_id: ua.questionId,
            selected_answer_id: ua.answerId,
            time_taken_ms: ua.timeTaken,
            is_correct: ua.isCorrect
          }))
        );

        navigate(`/review/${sessionData.id}`);
      }
    }
  };

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-24 flex items-center justify-center">
          <p className="text-muted-foreground">Loading quiz...</p>
        </div>
      </div>
    );
  }

  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          {/* Progress */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">
                Question {currentQuestionIndex + 1} of {questions.length}
              </span>
              <div className="flex items-center gap-2 text-sm font-semibold">
                <Clock className="h-4 w-4 text-primary" />
                <span className={timeLeft <= 10 ? "text-warning" : "text-foreground"}>
                  {timeLeft}s
                </span>
              </div>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Question Card */}
          <Card className="mb-6 bg-gradient-card border-border/50 shadow-card">
            <CardContent className="pt-8">
              <h2 className="text-2xl font-semibold mb-8">
                {questions[currentQuestionIndex].text}
              </h2>

              <div className="space-y-4">
                {loadingAnswers ? (
                  <>
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                    <Skeleton className="h-14 w-full" />
                  </>
                ) : (
                  answers.map((answer) => (
                    <Button
                      key={answer.id}
                      variant={selectedAnswer === answer.id ? "default" : "outline"}
                      className="w-full h-auto py-4 px-6 text-left justify-start hover:scale-[1.02] transition-transform"
                      onClick={() => handleAnswerSelect(answer.id)}
                    >
                      <span className="text-base">{answer.text}</span>
                    </Button>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          <Button 
            className="w-full shadow-glow" 
            size="lg"
            onClick={handleNext}
            disabled={!selectedAnswer}
          >
            {currentQuestionIndex < questions.length - 1 ? "Next Question" : "Finish Quiz"}
          </Button>
        </div>
      </div>
    </div>
  );
}