-- Seed questions for all categories
-- First, get all category IDs and insert questions for each

-- Insert questions for various football rule categories
-- We'll create 30 questions per category to ensure we have enough

-- Sample questions (you can expand this)
INSERT INTO public.questions (text, category_id) 
SELECT 'What is the minimum number of players required to start a match?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What is the maximum length of a football pitch?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What is the diameter of the center circle?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What is the minimum width of a football pitch?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What is the radius of the penalty area arc?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'How many substitutes are allowed in a standard match?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What color card results in a player being sent off?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'How many yellow cards result in a red card?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What is the duration of each half in a standard match?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What is the maximum circumference of a football?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'At what pressure should a football be inflated?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'Who decides the match ball to be used?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'How many match officials are there in a standard game?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What happens if the referee is injured during the match?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'How long is the half-time break?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'How is a match started at kick-off?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'Can a goal be scored directly from kick-off?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What happens when the ball is out of play?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'When is a goal scored?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What is offside position?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'Can you be offside in your own half?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'Is it an offside offense to receive the ball from a throw-in?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What is a direct free kick awarded for?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'Can you score directly from an indirect free kick?', id FROM question_categories LIMIT 1;

INSERT INTO public.questions (text, category_id)
SELECT 'What is the distance opponents must be from a free kick?', id FROM question_categories LIMIT 1;

-- Insert corresponding answers for each question
-- Question 1 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '7 players', true FROM questions WHERE text = 'What is the minimum number of players required to start a match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '8 players', false FROM questions WHERE text = 'What is the minimum number of players required to start a match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '9 players', false FROM questions WHERE text = 'What is the minimum number of players required to start a match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '6 players', false FROM questions WHERE text = 'What is the minimum number of players required to start a match?';

-- Question 2 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '120 meters', true FROM questions WHERE text = 'What is the maximum length of a football pitch?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '110 meters', false FROM questions WHERE text = 'What is the maximum length of a football pitch?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '130 meters', false FROM questions WHERE text = 'What is the maximum length of a football pitch?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '100 meters', false FROM questions WHERE text = 'What is the maximum length of a football pitch?';

-- Question 3 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '9.15 meters', true FROM questions WHERE text = 'What is the diameter of the center circle?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '10 meters', false FROM questions WHERE text = 'What is the diameter of the center circle?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '8 meters', false FROM questions WHERE text = 'What is the diameter of the center circle?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '9 meters', false FROM questions WHERE text = 'What is the diameter of the center circle?';

-- Question 4 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '45 meters', true FROM questions WHERE text = 'What is the minimum width of a football pitch?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '40 meters', false FROM questions WHERE text = 'What is the minimum width of a football pitch?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '50 meters', false FROM questions WHERE text = 'What is the minimum width of a football pitch?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '55 meters', false FROM questions WHERE text = 'What is the minimum width of a football pitch?';

-- Question 5 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '9.15 meters', true FROM questions WHERE text = 'What is the radius of the penalty area arc?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '10 meters', false FROM questions WHERE text = 'What is the radius of the penalty area arc?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '8 meters', false FROM questions WHERE text = 'What is the radius of the penalty area arc?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '11 meters', false FROM questions WHERE text = 'What is the radius of the penalty area arc?';

-- Question 6 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '5 substitutes', true FROM questions WHERE text = 'How many substitutes are allowed in a standard match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '3 substitutes', false FROM questions WHERE text = 'How many substitutes are allowed in a standard match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '7 substitutes', false FROM questions WHERE text = 'How many substitutes are allowed in a standard match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '6 substitutes', false FROM questions WHERE text = 'How many substitutes are allowed in a standard match?';

-- Question 7 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Red card', true FROM questions WHERE text = 'What color card results in a player being sent off?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Yellow card', false FROM questions WHERE text = 'What color card results in a player being sent off?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Blue card', false FROM questions WHERE text = 'What color card results in a player being sent off?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Green card', false FROM questions WHERE text = 'What color card results in a player being sent off?';

-- Question 8 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '2 yellow cards', true FROM questions WHERE text = 'How many yellow cards result in a red card?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '3 yellow cards', false FROM questions WHERE text = 'How many yellow cards result in a red card?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '1 yellow card', false FROM questions WHERE text = 'How many yellow cards result in a red card?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '4 yellow cards', false FROM questions WHERE text = 'How many yellow cards result in a red card?';

-- Question 9 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '45 minutes', true FROM questions WHERE text = 'What is the duration of each half in a standard match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '40 minutes', false FROM questions WHERE text = 'What is the duration of each half in a standard match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '50 minutes', false FROM questions WHERE text = 'What is the duration of each half in a standard match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '30 minutes', false FROM questions WHERE text = 'What is the duration of each half in a standard match?';

-- Question 10 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '70 cm', true FROM questions WHERE text = 'What is the maximum circumference of a football?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '75 cm', false FROM questions WHERE text = 'What is the maximum circumference of a football?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '65 cm', false FROM questions WHERE text = 'What is the maximum circumference of a football?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '72 cm', false FROM questions WHERE text = 'What is the maximum circumference of a football?';

-- Question 11 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '0.6 to 1.1 atmosphere', true FROM questions WHERE text = 'At what pressure should a football be inflated?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '0.5 to 1.0 atmosphere', false FROM questions WHERE text = 'At what pressure should a football be inflated?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '0.7 to 1.2 atmosphere', false FROM questions WHERE text = 'At what pressure should a football be inflated?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '1.0 to 1.5 atmosphere', false FROM questions WHERE text = 'At what pressure should a football be inflated?';

-- Question 12 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'The referee', true FROM questions WHERE text = 'Who decides the match ball to be used?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'The home team', false FROM questions WHERE text = 'Who decides the match ball to be used?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'The away team', false FROM questions WHERE text = 'Who decides the match ball to be used?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'The competition organizer', false FROM questions WHERE text = 'Who decides the match ball to be used?';

-- Question 13 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '4 officials', true FROM questions WHERE text = 'How many match officials are there in a standard game?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '3 officials', false FROM questions WHERE text = 'How many match officials are there in a standard game?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '5 officials', false FROM questions WHERE text = 'How many match officials are there in a standard game?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '2 officials', false FROM questions WHERE text = 'How many match officials are there in a standard game?';

-- Question 14 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'The fourth official takes over', true FROM questions WHERE text = 'What happens if the referee is injured during the match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'The match is abandoned', false FROM questions WHERE text = 'What happens if the referee is injured during the match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'An assistant referee takes over', false FROM questions WHERE text = 'What happens if the referee is injured during the match?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'The match continues without a referee', false FROM questions WHERE text = 'What happens if the referee is injured during the match?';

-- Question 15 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '15 minutes', true FROM questions WHERE text = 'How long is the half-time break?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '10 minutes', false FROM questions WHERE text = 'How long is the half-time break?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '20 minutes', false FROM questions WHERE text = 'How long is the half-time break?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '5 minutes', false FROM questions WHERE text = 'How long is the half-time break?';

-- Question 16 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Ball kicked forward from center spot', true FROM questions WHERE text = 'How is a match started at kick-off?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Ball dropped by referee', false FROM questions WHERE text = 'How is a match started at kick-off?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Ball thrown in from touchline', false FROM questions WHERE text = 'How is a match started at kick-off?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Ball kicked backward from center spot', false FROM questions WHERE text = 'How is a match started at kick-off?';

-- Question 17 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Yes', true FROM questions WHERE text = 'Can a goal be scored directly from kick-off?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'No', false FROM questions WHERE text = 'Can a goal be scored directly from kick-off?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Only in the opponent''s goal', false FROM questions WHERE text = 'Can a goal be scored directly from kick-off?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Only in extra time', false FROM questions WHERE text = 'Can a goal be scored directly from kick-off?';

-- Question 18 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Play stops until restarted', true FROM questions WHERE text = 'What happens when the ball is out of play?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Play continues', false FROM questions WHERE text = 'What happens when the ball is out of play?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'A goal is awarded', false FROM questions WHERE text = 'What happens when the ball is out of play?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'A penalty is given', false FROM questions WHERE text = 'What happens when the ball is out of play?';

-- Question 19 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'When ball crosses goal line between posts', true FROM questions WHERE text = 'When is a goal scored?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'When ball touches the net', false FROM questions WHERE text = 'When is a goal scored?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'When ball enters penalty area', false FROM questions WHERE text = 'When is a goal scored?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'When referee blows whistle', false FROM questions WHERE text = 'When is a goal scored?';

-- Question 20 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Nearer to goal line than ball and second-last opponent', true FROM questions WHERE text = 'What is offside position?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Beyond the halfway line', false FROM questions WHERE text = 'What is offside position?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Inside the penalty area', false FROM questions WHERE text = 'What is offside position?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Behind all defenders', false FROM questions WHERE text = 'What is offside position?';

-- Question 21 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'No', true FROM questions WHERE text = 'Can you be offside in your own half?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Yes', false FROM questions WHERE text = 'Can you be offside in your own half?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Only during corner kicks', false FROM questions WHERE text = 'Can you be offside in your own half?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Only in the penalty area', false FROM questions WHERE text = 'Can you be offside in your own half?';

-- Question 22 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'No', true FROM questions WHERE text = 'Is it an offside offense to receive the ball from a throw-in?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Yes', false FROM questions WHERE text = 'Is it an offside offense to receive the ball from a throw-in?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Only in opponent''s half', false FROM questions WHERE text = 'Is it an offside offense to receive the ball from a throw-in?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Only near the goal', false FROM questions WHERE text = 'Is it an offside offense to receive the ball from a throw-in?';

-- Question 23 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Fouls and misconduct', true FROM questions WHERE text = 'What is a direct free kick awarded for?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Offside', false FROM questions WHERE text = 'What is a direct free kick awarded for?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Ball out of play', false FROM questions WHERE text = 'What is a direct free kick awarded for?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Time wasting', false FROM questions WHERE text = 'What is a direct free kick awarded for?';

-- Question 24 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'No', true FROM questions WHERE text = 'Can you score directly from an indirect free kick?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Yes', false FROM questions WHERE text = 'Can you score directly from an indirect free kick?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Only in the penalty area', false FROM questions WHERE text = 'Can you score directly from an indirect free kick?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, 'Only from outside the box', false FROM questions WHERE text = 'Can you score directly from an indirect free kick?';

-- Question 25 answers
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '9.15 meters (10 yards)', true FROM questions WHERE text = 'What is the distance opponents must be from a free kick?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '10 meters', false FROM questions WHERE text = 'What is the distance opponents must be from a free kick?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '8 meters', false FROM questions WHERE text = 'What is the distance opponents must be from a free kick?';
INSERT INTO public.answers (question_id, text, is_correct)
SELECT id, '5 meters', false FROM questions WHERE text = 'What is the distance opponents must be from a free kick?';