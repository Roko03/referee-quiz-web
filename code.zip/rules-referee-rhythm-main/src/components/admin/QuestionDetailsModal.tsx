import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle } from "lucide-react";

type Question = {
  id: string;
  text: string;
  category_id: string;
  created_at: string;
  question_categories: { name: string } | null;
  answers: { id: string; text: string; is_correct: boolean }[];
};

type Props = {
  question: Question | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export const QuestionDetailsModal = ({ question, open, onOpenChange }: Props) => {
  if (!question) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Question Details</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground">Category</label>
            <Badge variant="secondary" className="mt-1">
              {question.question_categories?.name || "Unknown"}
            </Badge>
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground">Question</label>
            <p className="mt-2 text-lg">{question.text}</p>
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground mb-3 block">
              Answers
            </label>
            <div className="space-y-2">
              {question.answers.map((answer) => (
                <div
                  key={answer.id}
                  className={`p-3 rounded-lg border-2 flex items-center gap-3 ${
                    answer.is_correct
                      ? "border-green-500/50 bg-green-500/10"
                      : "border-border"
                  }`}
                >
                  {answer.is_correct ? (
                    <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0" />
                  ) : (
                    <XCircle className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                  )}
                  <span className={answer.is_correct ? "font-medium" : ""}>
                    {answer.text}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t">
            <p className="text-sm text-muted-foreground">
              Question ID: <span className="font-mono">{question.id}</span>
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              Created: {new Date(question.created_at).toLocaleDateString()}
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
